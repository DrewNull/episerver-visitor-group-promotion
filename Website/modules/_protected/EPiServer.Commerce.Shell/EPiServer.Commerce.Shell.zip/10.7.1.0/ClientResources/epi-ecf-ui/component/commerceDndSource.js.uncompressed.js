﻿define("epi-ecf-ui/component/commerceDndSource", [
    "dojo/_base/declare", // declare
    "dojo/_base/lang",

    "epi/shell/dnd/tree/dndSource"
], function (declare, lang, dndSource) {

    return declare([dndSource], {
        // summary:
        //      dnd source to supply catalog tree with the required dnd data
        // tags:
        //      internal

        getItem: function (/*String*/key) {
            var item = this.inherited(arguments);
            //add info about where the item was dragged from
            item.data.dndData.contextId = item.options.oldParentItem.contentLink;
            return item;
        }
    });
});
