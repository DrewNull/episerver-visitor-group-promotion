﻿define("epi-ecf-ui/widget/viewmodel/CatalogContentListViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

// epi
    "epi/shell/selection",
    "epi/shell/command/withConfirmation",

// epi-cms
    "epi-cms/widget/ContentTreeModelConfirmation",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",
    "epi-cms/command/CopyContent",
    "epi-cms/command/CutContent",
    "epi-cms/command/DeleteContent",
// commerce
    "../../command/DetachFromCategory",
    "../../command/PasteCatalogContent",
    "../../component/DeleteCatalogContentHandler",
    "epi-ecf-ui/widget/viewmodel/CatalogListViewModel",

// resources
    "epi/i18n!epi/cms/nls/commerce.widget.catalogcontentlist",
    "epi/i18n!epi/nls/episerver.shared"
], function(
// dojo
    declare,
    lang,

// epi
    Selection,
    withConfirmation,

// epi-cms
    ContentTreeModelConfirmation,
    ChangeContextCommand,
    NewContent,
    CopyCommand,
    CutCommand,
    DeleteCommand,

// commerce
    DetachFromCategory,
    PasteCatalogContent,
    DeleteCatalogContentHandler,
    CatalogListViewModel,

// resources
    resources,
    sharedresources
) {
    return declare([CatalogListViewModel], {

        res: resources,

        getSelectionCommands: function() {
            return [
                this._commandRegistry.cut.command,
                this._commandRegistry.copy.command,
                this._commandRegistry.pasteOnContext.command,
                this._commandRegistry.detach.command,
                this._commandRegistry.remove.command
            ];
        },

        _setupCommands: function () {

            var commandSettings = {
                category: "context",
                clipboard: this.clipboardManager,
                selection: this.selection,
                model: this.treeStoreModel
            };

            var toolbarGroupSettings = lang.mixin({ toolbarGroup: "clipboard" }, commandSettings);
            var deleteCommand = new DeleteCommand(lang.mixin({ model: this.treeStoreModel }, commandSettings));

            lang.mixin(this._commandRegistry, this.getCreateCommands());
            lang.mixin(this._commandRegistry, {
                edit: {
                    command: new ChangeContextCommand({
                        category: "context",
                        forceContextChange: true,
                        viewName: "formedit"
                    }),
                    order: -1
                },
                cut: {
                    command: new CutCommand(toolbarGroupSettings),
                    order: 101
                },
                copy: {
                    command: new CopyCommand(toolbarGroupSettings),
                    order: 102
                },
                paste: {
                    command: new PasteCatalogContent(commandSettings),
                    order: 103
                },
                pasteOnContext: {
                    command: new PasteCatalogContent(lang.mixin(toolbarGroupSettings, { selection: new Selection() }))
                },
                detach: {
                    command: withConfirmation(new DetachFromCategory(commandSettings), null, {
                        title: this.res.detachconfirmation.title,
                        description: this.res.detachconfirmation.description
                    }),
                    order: 104
                },
                remove: {
                    command: withConfirmation(deleteCommand, DeleteCatalogContentHandler, {
                        title: this.res.deleteconfirmation.title,
                        description: this.res.deleteconfirmation.description,
                        confirmActionText: sharedresources.action.deletelabel,
                        cancelActionText: sharedresources.action.cancel
                    }),
                    order: 105
                }
            });
            this.set("commands", this._commandRegistry.toArray());
        }
    });
});